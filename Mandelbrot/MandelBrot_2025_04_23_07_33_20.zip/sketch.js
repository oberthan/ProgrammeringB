let buf;              // off-screen buffer
let bufRes = 0.1;     // buffer resolution factor (0.5 = half size)
let centerX, centerY, scale;
let maxIter = 50;

function setup() {
  createCanvas(600, 600);
  pixelDensity(1);
  // make buffer at lower resolution
  buf = createGraphics(width * bufRes, height * bufRes);
  buf.pixelDensity(1);
  
  centerX = new Decimal(-0.5);
  centerY = new Decimal(0);
  scale   = new Decimal(3);
  noLoop();
}

function draw() {
  // draw Mandelbrot into buf
  buf.loadPixels();
  const w = buf.width, h = buf.height;
  const two = new Decimal(2), four = new Decimal(4);
  
  for (let py = 0; py < h; py++) {
    const im0 = centerY.plus(scale.times(new Decimal(py / h - 0.5)));
    for (let px = 0; px < w; px++) {
      const re0 = centerX.plus(scale.times(new Decimal(px / w - 0.5)));
      let re = new Decimal(0), im = new Decimal(0);
      let iter = 0;
      while (iter < maxIter && re.times(re).plus(im.times(im)).lt(four)) {
        const re2 = re.times(re).minus(im.times(im)).plus(re0);
        const im2 = two.times(re).times(im).plus(im0);
        re = re2; im = im2;
        iter++;
      }
      const br = iter === maxIter ? 0 : map(iter, 0, maxIter, 0, 255);
      const idx = 4 * (px + py * w);
      buf.pixels[idx] = buf.pixels[idx+1] = buf.pixels[idx+2] = br;
      buf.pixels[idx+3] = 255;
    }
  }
  buf.updatePixels();
  
  // scale buffer up to full canvas
  image(buf, 0, 0, width, height);
}

function mouseWheel(event) {
  const zoomFactor = event.delta > 0 ? 1.1 : 0.9;
  scale = scale.times(zoomFactor);
  const dx = new Decimal(mouseX/width - 0.5).times(scale);
  const dy = new Decimal(mouseY/height - 0.5).times(scale);
  centerX = centerX.plus(dx);
  centerY = centerY.plus(dy);
  redraw();
  return false;
}